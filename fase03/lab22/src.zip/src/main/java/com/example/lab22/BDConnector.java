package com.example.lab22;

public class BDConnector {
}
